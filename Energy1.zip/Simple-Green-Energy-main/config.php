<?php

// define('DB_HOST', 'localhost');
// define('DB_USERNAME', 'rectubmx_simplegreen');
// define('DB_PASSWORD', '3N2h0DEwaDJ#');
// define('DB_NAME', 'rectubmx_simplegreenenergy');



// // Establish a database connection
// $conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

//local run

// Database configuration
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "rectubmx_simplegreenenergy";

// Create a database connection
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>
