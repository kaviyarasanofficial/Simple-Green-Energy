<?php
// Start the session to access session variables
session_start();

// Check if the user is not logged in (no session variable is set)
if (!isset($_SESSION['email'])) {
    // Redirect to the login page or handle the unauthorized access as needed
    header("Location: signin.php");
    exit();
}

// Get the user's email from the session
$userEmail = $_SESSION['email'];

$ds = DIRECTORY_SEPARATOR;
$storeFolder = 'uploads' . $ds . $userEmail; // Create a folder for each user based on their email

if (!empty($_FILES)) {
    $tempFile = $_FILES['file']['tmp_name'];
    $targetPath = dirname(__FILE__) . $ds . $storeFolder . $ds;
    $targetFile = $targetPath . $_FILES['file']['name'];

    // Create the user's folder if it doesn't exist
    if (!file_exists($targetPath)) {
        mkdir($targetPath, 0777, true);
    }

    move_uploaded_file($tempFile, $targetFile);
    // You may want to add error handling and validation here
}
?>
